﻿#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# bot_master_adaptive.py – финальная версия с адаптивным режимом и сохранением состояния

import sys, os, time, pandas as pd, numpy as np, requests
from datetime import datetime, timedelta
from dotenv import load_dotenv

sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from core.client import client
from core.logger import logger
from config import LIVE_TRADING
import indicators

load_dotenv()

# ---------- модуль состояния (заглушка, если нет core.state) ----------
STATE_AVAILABLE = False
try:
    from core.state import save_state, load_state, clear_state
    STATE_AVAILABLE = True
except ImportError:
    def save_state(*args, **kwargs): pass
    def load_state(*args, **kwargs): return None
    def clear_state(*args, **kwargs): pass
    logger.warning("Модуль core.state не найден, сохранение состояния отключено")

# ---------- конфигурация монет ----------
COIN_CONFIG = {
    "BTCUSDT": {
        "trend": {"rsi_low": 35, "rsi_high": 65, "ema": 200, "tp_sl_ratio": 3, "sl_percent": 1.2},
        "volume": {"lookback": 50, "value_area_volume": 0.7, "tp_sl_ratio": 3, "sl_percent": 1.2},
        "adx_threshold": 25,
        "risk_per_trade": 0.02
    },
    "BNBUSDT": {
        "trend": {"rsi_low": 40, "rsi_high": 65, "ema": 200, "tp_sl_ratio": 5, "sl_percent": 1.2},
        "volume": {"lookback": 50, "value_area_volume": 0.7, "tp_sl_ratio": 5, "sl_percent": 1.2},
        "adx_threshold": 25,
        "risk_per_trade": 0.02
    },
    "XRPUSDT": {
        "trend": {"rsi_low": 35, "rsi_high": 65, "ema": 100, "tp_sl_ratio": 4, "sl_percent": 1.2},
        "volume": {"lookback": 50, "value_area_volume": 0.7, "tp_sl_ratio": 4, "sl_percent": 1.2},
        "adx_threshold": 25,
        "risk_per_trade": 0.02
    },
    "SOLUSDT": {
        "trend": {"rsi_low": 40, "rsi_high": 70, "ema": 100, "tp_sl_ratio": 5, "sl_percent": 1.2},
        "volume": {"lookback": 50, "value_area_volume": 0.7, "tp_sl_ratio": 5, "sl_percent": 1.2},
        "adx_threshold": 25,
        "risk_per_trade": 0.02
    }
}

# ---------- загрузка данных ----------
def fetch_klines(symbol, interval='1h', limit=200):
    url = f"https://api.binance.com/api/v3/klines?symbol={symbol}&interval={interval}&limit={limit}"
    try:
        data = requests.get(url, timeout=10).json()
        rows = []
        for k in data:
            rows.append({
                'timestamp': datetime.fromtimestamp(k[0]/1000),
                'open': float(k[1]),
                'high': float(k[2]),
                'low': float(k[3]),
                'close': float(k[4]),
                'volume': float(k[5])
            })
        df = pd.DataFrame(rows)
        return df.sort_values('timestamp').reset_index(drop=True)
    except Exception as e:
        logger.error(f"Ошибка загрузки {symbol}: {e}")
        return pd.DataFrame()

# ---------- стратегии ----------
class TrendStrategy:
    def __init__(self, params):
        self.rsi_low = params['rsi_low']
        self.rsi_high = params['rsi_high']
        self.ema_period = params['ema']
        self.sl_percent = params['sl_percent']
        self.tp_sl_ratio = params['tp_sl_ratio']
        self.name = "TREND"
    def get_signal(self, df, current_price):
        if len(df) < self.ema_period: return None
        ema = df['close'].ewm(span=self.ema_period, adjust=False).mean().iloc[-1]
        if len(df) < 30: return None
        delta = df['close'].diff()
        gain = delta.clip(lower=0)
        loss = -delta.clip(upper=0)
        avg_gain = gain.rolling(window=14).mean().iloc[-1]
        avg_loss = loss.rolling(window=14).mean().iloc[-1]
        if avg_loss == 0: rsi = 100
        else: rsi = 100 - 100/(1+avg_gain/avg_loss)
        if rsi < self.rsi_low and current_price > ema:
            sl = current_price * (1 - self.sl_percent/100)
            tp = current_price * (1 + self.sl_percent/100 * self.tp_sl_ratio)
            return {"action": "LONG", "sl": sl, "tp": tp, "confidence": 70}
        elif rsi > self.rsi_high and current_price < ema:
            sl = current_price * (1 + self.sl_percent/100)
            tp = current_price * (1 - self.sl_percent/100 * self.tp_sl_ratio)
            return {"action": "SHORT", "sl": sl, "tp": tp, "confidence": 70}
        return None

class VolumeProfileStrategy:
    def __init__(self, params):
        self.lookback = params['lookback']
        self.sl_percent = params['sl_percent']
        self.tp_sl_ratio = params['tp_sl_ratio']
        self.name = "VOLUME_PROFILE"
    def get_signal(self, df, current_price):
        if len(df) < self.lookback: return None
        period_df = df.iloc[-self.lookback:]
        price_high = period_df['high'].max()
        price_low = period_df['low'].min()
        bins = 50
        price_step = (price_high - price_low) / bins
        levels = []
        volumes = []
        for b in range(bins):
            lower = price_low + b * price_step
            upper = lower + price_step
            vol_sum = 0
            for _, row in period_df.iterrows():
                if row['high'] >= lower and row['low'] <= upper:
                    vol_sum += row['volume']
            levels.append((lower + upper)/2)
            volumes.append(vol_sum)
        if not volumes: return None
        poc_idx = np.argmax(volumes)
        poc = levels[poc_idx]
        deviation = (current_price - poc) / poc * 100
        if deviation < -0.8:
            sl = current_price * (1 - self.sl_percent/100)
            tp = current_price * (1 + self.sl_percent/100 * self.tp_sl_ratio)
            return {"action": "LONG", "sl": sl, "tp": tp, "confidence": 60}
        elif deviation > 0.8:
            sl = current_price * (1 + self.sl_percent/100)
            tp = current_price * (1 - self.sl_percent/100 * self.tp_sl_ratio)
            return {"action": "SHORT", "sl": sl, "tp": tp, "confidence": 60}
        return None

# ---------- адаптивный оркестратор ----------
class AdaptiveOrchestrator:
    def __init__(self, config, is_bull):
        if is_bull:
            self.trend = TrendStrategy(config['trend'])
            self.volume = None
        else:
            # медвежьи параметры (более жёсткие)
            bear_trend_params = config['trend'].copy()
            bear_trend_params.update({'rsi_low':30, 'rsi_high':55, 'ema':50, 'tp_sl_ratio':2, 'sl_percent':1.0})
            self.trend = TrendStrategy(bear_trend_params)
            self.volume = None   # volume отключаем в медвежьем режиме
        self.adx_threshold = config['adx_threshold']
        self.name = "TREND_BEAR" if not is_bull else "TREND"
    def get_signal(self, df, adx):
        if adx < self.adx_threshold:
            return None
        signal = self.trend.get_signal(df, df.iloc[-1]['close'])
        if signal:
            signal['strategy'] = self.name
        return signal

# ---------- основной бот ----------
class MasterBot:
    def __init__(self, symbols):
        self.symbols = symbols
        self.positions = {sym: None for sym in symbols}
        self.balances = {sym: 1000 for sym in symbols}
        self.orchestrators = {}
        self.last_save = 0
        self.load_positions()
        # загружаем дневные данные для определения тренда
        self.daily_cache = {}
        self.update_trend()
    def update_trend(self):
        for sym in self.symbols:
            df_d = fetch_klines(sym, '1d', 250)
            if not df_d.empty and len(df_d) >= 200:
                sma200 = df_d['close'].rolling(200).mean().iloc[-1]
                is_bull = df_d.iloc[-1]['close'] > sma200
                self.orchestrators[sym] = AdaptiveOrchestrator(COIN_CONFIG[sym], is_bull)
                logger.info(f"[TREND] {sym} -> {'BULL' if is_bull else 'BEAR'} (price={df_d.iloc[-1]['close']:.2f}, SMA200={sma200:.2f})")
    def load_positions(self):
        if not STATE_AVAILABLE: return
        state = load_state()
        if state and 'open_position' in state:
            op = state['open_position']
            sym = op.get('symbol')
            if sym in self.symbols:
                self.positions[sym] = {
                    'type': op['position_type'],
                    'entry': op['entry_price'],
                    'sl_pct': op.get('sl_pct', 1.2),
                    'tp_pct': op.get('tp_pct', 3.6),
                    'strategy': op.get('strategy', 'TREND')
                }
                logger.info(f"Загружена позиция {sym} {op['position_type']} по {op['entry_price']}")
    def save_all_positions(self):
        if not STATE_AVAILABLE: return
        for sym, pos in self.positions.items():
            if pos is not None:
                try:
                    portfolio_mock = type('Portfolio', (), {
                        'balance': self.balances[sym],
                        'trade_history': [],
                        'positions': {sym: {
                            'entry_price': pos['entry'],
                            'position_type': pos['type'],
                            'amount': 0,
                            'commission': 0,
                            'sl_pct': pos.get('sl_pct', 1.2),
                            'tp_pct': pos.get('tp_pct', 3.6),
                            'strategy': pos.get('strategy', 'TREND')
                        }}
                    })()
                    save_state(portfolio_mock, pos['type'], 0, pos['entry'])
                except Exception as e:
                    logger.error(f"Failed to save state: {e}")
    def run(self):
        logger.info("Запуск MASTER BOT (адаптивный, с сохранением состояния)")
        self.update_trend()
        while True:
            try:
                for sym in self.symbols:
                    df = fetch_klines(sym, '1h', 200)
                    if df.empty: continue
                    current_price = df.iloc[-1]['close']
                    adx_val = indicators.adx(df['close'].values, 14)
                    if adx_val is None: adx_val = 20.0
                    orch = self.orchestrators.get(sym)
                    if orch is None: continue
                    if self.positions[sym] is not None:
                        pos = self.positions[sym]
                        pnl_pct = ((current_price - pos['entry']) / pos['entry']) * 100 if pos['type'] == 'LONG' else ((pos['entry'] - current_price) / pos['entry']) * 100
                        if pnl_pct <= -pos.get('sl_pct', 1.2):
                            logger.info(f"[CLOSE] {sym} {pos['type']} SL ({pnl_pct:.2f}%)")
                            self.positions[sym] = None
                            self.save_all_positions()
                        elif pnl_pct >= pos.get('tp_pct', 3.6):
                            logger.info(f"[CLOSE] {sym} {pos['type']} TP ({pnl_pct:.2f}%)")
                            self.positions[sym] = None
                            self.save_all_positions()
                    else:
                        signal = orch.get_signal(df, adx_val)
                        if signal:
                            action = signal['action']
                            sl = signal['sl']
                            tp = signal['tp']
                            sl_pct = abs((sl - current_price) / current_price) * 100
                            tp_pct = abs((tp - current_price) / current_price) * 100
                            logger.info(f"[SIGNAL] {sym} {action} | Стратегия: {orch.name} | ADX={adx_val:.1f} | Цена={current_price:.2f} | SL={sl_pct:.1f}% | TP={tp_pct:.1f}%")
                            self.positions[sym] = {
                                'type': action,
                                'entry': current_price,
                                'sl_pct': sl_pct,
                                'tp_pct': tp_pct,
                                'strategy': orch.name
                            }
                            self.save_all_positions()
                time.sleep(3600)  # 1 час
            except KeyboardInterrupt:
                logger.info("Остановка по запросу")
                self.save_all_positions()
                break
            except Exception as e:
                logger.error(f"Ошибка: {e}")
                time.sleep(60)

if __name__ == "__main__":
    symbols = ["BTCUSDT", "BNBUSDT", "XRPUSDT", "SOLUSDT"]
    bot = MasterBot(symbols)
    bot.run()