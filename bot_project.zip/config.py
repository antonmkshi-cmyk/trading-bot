﻿#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# config.py - Р•РґРёРЅС‹Р№ РєРѕРЅС„РёРіСѓСЂР°С†РёРѕРЅРЅС‹Р№ С†РµРЅС‚СЂ "РћСЂРєРµСЃС‚СЂР°"

import os
from dotenv import load_dotenv

load_dotenv()

# ==========================================
# 1. PIONEX API CONFIG (Р‘РР Р–Рђ)
# ==========================================
API_KEY = os.getenv("PIONEX_API_KEY")
API_SECRET = os.getenv("PIONEX_API_SECRET")
BASE_URL = os.getenv("PIONEX_BASE_URL", "https://api.pionex.com")

# ==========================================
# 2. MARKET & BALANCE (Р Р«РќРћРљ Р Р”Р•РџРћР—РРў)
# ==========================================
SYMBOL = "BTC_USDT"
MARKET_INTERVAL = 10     # РРЅС‚РµСЂРІР°Р» РїСЂРѕРІРµСЂРєРё РІ СЃРµРєСѓРЅРґР°С…
START_BALANCE = 1000     # РЎС‚Р°СЂС‚РѕРІС‹Р№ РєР°РїРёС‚Р°Р» РґР»СЏ Р±СЌРєС‚РµСЃС‚Р°

# ==========================================
# 3. EXECUTION MODE (Р Р•Р–РРњ Р РђР‘РћРўР«)
# ==========================================
LIVE_TRADING = False     # True вЂ” СЂРµР°Р»СЊРЅС‹Рµ С‚РѕСЂРіРё, False вЂ” Р±СѓРјР°Р¶РЅС‹Р№ СЂРµР¶РёРј
REQUEST_TIMEOUT = 10
LOG_LEVEL = "INFO"

# ==========================================
# 4. QUANTUM ORCHESTRA & WEIGHTS (РђРќРЎРђРњР‘Р›Р¬)
# ==========================================
ENTRY_THRESHOLD = 15.0

WEIGHT_FLAT_SNIPER = 0.5
WEIGHT_TREND_FOLLOWER = 0.5

# ==========================================
# 5. STRATEGY: ADAPTIVE FLAT SNIPER (РЎРќРђР™РџР•Р )
# ==========================================
SNIPER_BB_PERIOD = 20
SNIPER_BB_STD = 2.0
SNIPER_STOCH_PERIOD = 14
SNIPER_MAX_BB_WIDTH = 0.05

RSI_PERIOD = 14
RSI_BUY_LIMIT = 35
RSI_SELL_LIMIT = 65

# ==========================================
# 6. STRATEGY: ADAPTIVE TREND FOLLOWER (РўР Р•РќР”)
# ==========================================
TREND_SMA_PERIOD = 50
TREND_ATR_MULTIPLIER = 0.5
TREND_ATR_THRESHOLD = 0.001

# ==========================================
# 7. RISK MANAGEMENT (РљРћРќРўР РћР›Р¬ РџРћРўР•Р Р¬)
# ==========================================
STOP_LOSS_PERCENT = 1.5
TAKE_PROFIT_PERCENT = 0.8
TRAILING_STOP_PERCENT = 0.8

RISK_PER_TRADE = 2
MAX_POSITION_SIZE_USDT = 150
MAX_DAILY_LOSS = 50
CONSECUTIVE_LOSS_LIMIT = 4

# ==========================================
# 8. TIMING & PROTECTIONS (РўРђР™РњРРќР“Р)
# ==========================================
MIN_CYCLES_IN_POSITION = 2
MAX_CYCLES_IN_POSITION = 20
COOLDOWN_CYCLES = 3
MIN_TRADE_INTERVAL = 3

# ==========================================
# 9. EXECUTION COSTS & FILTERS (РљРћРњРРЎРЎРР)
# ==========================================
COMMISSION_PERCENT = 0.05
SLIPPAGE_PERCENT = 0.02

MIN_VOLATILITY = 0.008
MIN_VOLATILITY_FOR_TRADING = 0.05
MIN_TP_TO_COVER_FEES = 0.25



