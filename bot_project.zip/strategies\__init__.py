#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# strategies/__init__.py

from .sniper_mtf import SniperMTFStrategy
from .trend_follower import TrendFollowerStrategy
from .impulse_hunter import ImpulseHunterStrategy
from .mean_reversion import MeanReversionStrategy
from .knife_catcher import KnifeCatcherStrategy
from .double_confirmation import DoubleConfirmationStrategy # Добавили