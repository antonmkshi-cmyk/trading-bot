#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# strategies/double_confirmation.py

import indicators

class DoubleConfirmationStrategy:
    def __init__(self):
        self.name = "Double_Confirmation_V1.6"

    def get_signal(self, history_5m, bb_width_15m):
        if len(history_5m) < 25:
            return "HOLD"

        current_price = history_5m[-1]
        
        # 1. Расширили фильтр старшей волатильности до 5%
        if bb_width_15m > 0.05: 
            return "HOLD"

        # 2. Считаем Боллинджер со множителем 1.9 для лучшей чувствительности
        sma_20 = indicators.sma(history_5m, period=20)
        variance = sum((x - sma_20) ** 2 for x in history_5m[-20:]) / 20
        std_dev = variance ** 0.5
        upper_band = sma_20 + (1.9 * std_dev)
        lower_band = sma_20 - (1.9 * std_dev)

        # 3. Чистый Стохастик текущей свечи
        stoch_val = indicators.stoch(history_5m, period=14)

        if stoch_val is None or stoch_val < 0 or stoch_val > 100:
            return "HOLD"

        # 4. Сбалансированные триггеры входа
        if current_price <= lower_band and stoch_val < 20.0:
            return "LONG"
            
        elif current_price >= upper_band and stoch_val > 80.0:
            return "SHORT"

        return "HOLD"