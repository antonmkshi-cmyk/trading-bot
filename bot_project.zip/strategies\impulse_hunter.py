#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# strategies/impulse_hunter.py

import indicators

class ImpulseHunterStrategy:
    def __init__(self):
        self.name = "Impulse_Hunter_V1.1"

    def get_signal(self, history_5m, volumes_5m):
        """
        Ищет ИСТИННЫЕ взрывные импульсы на объёмах.
        """
        if len(history_5m) < 20 or len(volumes_5m) < 20:
            return "HOLD"

        current_volume = volumes_5m[-1]
        avg_volume = sum(volumes_5m[-20:-1]) / 19

        current_price = history_5m[-1]
        prev_price = history_5m[-2]

        # Объём должен быть в 3.5 раза выше среднего
        volume_spike = current_volume > (avg_volume * 3.5)
        
        if volume_spike:
            # Планка поднята до 0.55% для отсечения ложных выносов
            if current_price > prev_price * 1.0055: 
                return "LONG"
            elif current_price < prev_price * 0.9945: 
                return "SHORT"

        return "HOLD"