#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# strategies/knife_catcher.py

import indicators

class KnifeCatcherStrategy:
    def __init__(self):
        self.name = "Knife_Catcher_V1.0"

    def get_signal(self, history_5m):
        """
        Ловит вертикальные проливы («панические ножи») при экстремальном RSI.
        """
        if len(history_5m) < 14:
            return "HOLD"

        current_price = history_5m[-1]
        sma_50 = indicators.sma(history_5m, period=50)
        rsi_val = indicators.rsi(history_5m, period=14)

        # Вычисляем отклонение от тяжелой средней в процентах
        distance = (current_price - sma_50) / sma_50 * 100

        # Экстремальная паника: цена улетела вниз на 2.5% от средней, RSI на дне
        if distance <= -2.5 and rsi_val <= 15:
            return "LONG"
        # Экстремальный хайп (вертикальная палка вверх)
        elif distance >= 2.5 and rsi_val >= 85:
            return "SHORT"

        return "HOLD"