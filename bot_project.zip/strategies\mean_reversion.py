#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# strategies/mean_reversion.py

import indicators

class MeanReversionStrategy:
    def __init__(self):
        self.name = "Mean_Reversion_V1.1"

    def get_signal(self, history_5m):
        if len(history_5m) < 20:
            return "HOLD"

        current_price = history_5m[-1]
        sma_20 = indicators.sma(history_5m, period=20)
        stoch_val = indicators.stoch(history_5m, period=14)

        # Сделали фильтр в 3 раза строже (0.6% отклонения вместо 0.2%)
        if stoch_val < 15.0 and current_price < sma_20 * 0.994:
            return "LONG"
        elif stoch_val > 85.0 and current_price > sma_20 * 1.006:
            return "SHORT"

        return "HOLD"