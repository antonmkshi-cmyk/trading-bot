﻿#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# strategies/sniper_mtf.py

import math
import config 
# Импортируем твой RSI из правильного файла
from indicators.oscillators import calculate_rsi

class SniperMTFStrategy:
    def __init__(self):
        self.name = "ADAPTIVE_FLAT_SNIPER"

    def get_signal_score(self, context, volatility_scalar):
        """
        Адаптивная флэтовая стратегия. 
        Подстраивает каналы Боллинджера и фильтр RSI под волатильность любой монеты.
        """
        # Базовая проверка на валидность данных в контексте
        if not context or not hasattr(context, 'closes_5m') or not context.closes_5m:
            return 0

        history = context.closes_5m
        current_price = history[-1]
        
        # Защита от короткой истории на старте бэктеста
        sma_period = getattr(config, 'SNIPER_BB_PERIOD', 20)
        rsi_period = getattr(config, 'RSI_PERIOD', 14)
        required_candles = max(sma_period, rsi_period + 1)
        
        if len(history) < required_candles:
            return 0

        # --- 1. АВТОНОМНЫЙ РАСЧЕТ БОЛЛИНДЖЕРА ---
        # Динамическое отклонение: базовое (например, 2.0) умножаем на скаляр волатильности рынка
        base_std = getattr(config, 'SNIPER_BB_STD', 2.0)
        dynamic_std = base_std * volatility_scalar
        
        # Считаем SMA (Простую Скользящую Среднюю) по закрытиям
        recent_closes = history[-sma_period:]
        sma_20 = sum(recent_closes) / sma_period
        
        # Считаем Стандартное Отклонение
        variance = sum((x - sma_20) ** 2 for x in recent_closes) / sma_period
        std_dev = variance ** 0.5
        
        # Строим динамический коридор
        upper_band = sma_20 + (dynamic_std * std_dev)
        lower_band = sma_20 - (dynamic_std * std_dev)

        # --- 2. АДАПТИВНЫЙ RSI ---
        # Если монета волатильная (scalar > 1), раздвигаем рамки RSI, чтобы не ловить ножи.
        # Если на рынке штиль (scalar < 1), сужаем рамки, чтобы брать мелкие флэтовые движения.
        base_rsi_buy = getattr(config, 'RSI_BUY_LIMIT', 30)
        base_rsi_sell = getattr(config, 'RSI_SELL_LIMIT', 70)
        
        dynamic_rsi_buy = base_rsi_buy - (2.0 * volatility_scalar)
        dynamic_rsi_sell = base_rsi_sell + (2.0 * volatility_scalar)
        
        # Вызываем твою функцию расчета RSI
        current_rsi = calculate_rsi(history, period=rsi_period)

        # ⚡ КРИТИЧЕСКАЯ ЗАЩИТА: проверяем, что RSI рассчитался корректно
        if current_rsi is None or (isinstance(current_rsi, float) and math.isnan(current_rsi)):
            return 0  # Пропускаем свечу, если нет данных по RSI

        # --- 3. ГЕНЕРАЦИЯ СИГНАЛА (СИНЕРГИЯ ИНДИКАТОРОВ) ---
        # LONG: Цена пробила нижнюю ленту Боллинджера И RSI ушел в перепроданность
        if current_price <= lower_band and current_rsi <= dynamic_rsi_buy:
            return 100
            
        # SHORT: Цена пробила верхнюю ленту Боллинджера И RSI ушел в перекупленность
        elif current_price >= upper_band and current_rsi >= dynamic_rsi_sell:
            return -100

        # Рынок в середине канала — сидим на заборе
        return 0