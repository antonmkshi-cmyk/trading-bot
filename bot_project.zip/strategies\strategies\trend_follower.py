#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# strategies/trend_follower.py

import indicators
import logging

logger = logging.getLogger("Orchestra.TrendFollower")

class TrendFollowerStrategy:
    def __init__(self):
        self.name = "TREND_FOLLOWER_V5.5"

    def get_signal_score(self, context, *args, **kwargs):
        """
        Ищет сильные трендовые движения.
        Возвращает балл от -100 (Short тренд) до +100 (Long тренд).
        
        *args и **kwargs добавлены для защиты от TypeError, если ядро бота
        передает лишние позиционные или именованные аргументы при вызове.
        """
        # 1. Проверяем валидность контекста
        if context is None or not getattr(context, 'is_valid', False):
            return 0

        try:
            history = context.closes_5m
            
            # Защита: если история пустая или в ней критически мало свечей
            if not history or len(history) < 50:
                return 0
                
            current_price = history[-1]
            
            # Защита: если последняя цена по какой-то причине None
            if current_price is None:
                return 0

            # 2. Расчет SMA-50
            sma_value = indicators.sma(history, period=50)
            
            # Если твоя библиотека indicators.sma возвращает список свечей, берем последнюю.
            # Если возвращает сразу число (float), оставляем как есть.
            if isinstance(sma_value, list):
                sma_50 = sma_value[-1] if sma_value else None
            else:
                sma_50 = sma_value

            # 3. Жесткая проверка на NoneType перед математическими операциями
            if sma_50 is None:
                return 0

            # 4. Трендовый фильтр с запасом (0.2%)
            if current_price >= sma_50 * 1.002:
                return 100  # Уверенный тренд вверх
            elif current_price <= sma_50 * 0.998:
                return -100 # Уверенный тренд вниз

            return 0 # Пилим вокруг средней — тренда нет, бот молчит
            
        except Exception as e:
            # Предотвращает остановку всего бота при непредвиденной ошибке внутри расчета
            logger.error(f"Критическая ошибка в расчете {self.name}: {e}")
            return 0