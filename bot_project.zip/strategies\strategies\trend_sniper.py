﻿# strategies/trend_sniper.py — супер-упрощённая версия

import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import indicators


class TrendSniperStrategy:
    def __init__(self):
        self.name = "TREND_SNIPER"

    def get_signal_score(self, context, volatility_scalar):
        prices = context.closes_5m
        if len(prices) < 30:
            return 0

        current_price = prices[-1]

        # Только RSI и ADX, никакой EMA
        adx = indicators.adx(prices, period=14)
        rsi = indicators.rsi(prices, period=14)

        if adx is None or rsi is None:
            return 0

        # : печатаем значения каждые 100 свечей
        if len(prices) % 100 == 0:
            print(f"[DEBUG] ADX={adx:.1f}, RSI={rsi:.1f}, цена={current_price:.0f}")

        # чень мягкие условия
        if adx > 20 and rsi < 45:
            return 80  # LONG
        elif adx > 20 and rsi > 55:
            return -80  # SHORT

        return 0
