from core.logger import logger
from risk.risk_manager import RiskManager

# ==========================================
# ORDER MANAGER
# ==========================================

class OrderManager:

    def __init__(self):

        self.risk = RiskManager()

    # ==========================================
    # FAKE BUY ORDER
    # ==========================================

    def place_buy_order(
        self,
        symbol,
        amount,
        price
    ):

        logger.info(
            f"Creating BUY order: "
            f"{symbol} | amount={amount} | price={price}"
        )

        # RISK CHECK

        allowed = self.risk.check_position_size(
            amount
        )

        if not allowed:

            logger.warning(
                "BUY order blocked by risk manager"
            )

            return False

        logger.info(
            "BUY order simulated successfully"
        )

        return True

    # ==========================================
    # FAKE SELL ORDER
    # ==========================================

    def place_sell_order(
        self,
        symbol,
        amount,
        price
    ):

        logger.info(
            f"Creating SELL order: "
            f"{symbol} | amount={amount} | price={price}"
        )

        allowed = self.risk.check_position_size(
            amount
        )

        if not allowed:

            logger.warning(
                "SELL order blocked by risk manager"
            )

            return False

        logger.info(
            "SELL order simulated successfully"
        )

        return True