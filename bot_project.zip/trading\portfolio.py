from config import COMMISSION_PERCENT
from core.logger import logger

# ==========================================
# PORTFOLIO CLASS
# ==========================================

class Portfolio:

    def __init__(self, initial_balance):
        self.balance = initial_balance
        self.positions = {}
        self.trade_history = []
        logger.info(f"Portfolio created | USDT balance: {self.balance}")

    # ======================================
    # OPEN POSITION
    # ======================================

    def buy_asset(self, symbol, amount, current_price, position_type="LONG"):
        position_cost = amount * current_price
        commission = position_cost * COMMISSION_PERCENT / 100
        total_cost = position_cost + commission

        if total_cost > self.balance:
            logger.warning("Not enough balance")
            return False

        self.balance -= total_cost

        self.positions[symbol] = {
            "symbol": symbol,
            "entry_price": current_price,
            "amount": amount,
            "commission": commission,
            "position_type": position_type,
            "max_profit": 0.0
        }

        logger.info(f"BUY executed | {symbol} | {position_type} | amount={amount} | price={current_price}")
        return True

    # ======================================
    # CLOSE POSITION
    # ======================================

    def sell_asset(self, symbol, current_price, position_type="LONG"):
        if symbol not in self.positions:
            logger.warning("No position found")
            return None

        position = self.positions[symbol]
        amount = position["amount"]
        entry_price = position["entry_price"]
        buy_commission = position["commission"]
        actual_position_type = position.get("position_type", position_type)

        sell_value = amount * current_price
        sell_commission = sell_value * COMMISSION_PERCENT / 100
        net_sell_value = sell_value - sell_commission

        # ==========================================
        # PnL CALCULATION FOR LONG AND SHORT
        # ==========================================

        if actual_position_type == "LONG":
            # LONG: profit when price goes up
            pnl = net_sell_value - (entry_price * amount) - buy_commission
        else:  # SHORT
            # SHORT: profit when price goes down
            pnl = (entry_price * amount) - net_sell_value - buy_commission

        trade = {
            "symbol": symbol,
            "entry_price": entry_price,
            "exit_price": current_price,
            "amount": amount,
            "pnl": pnl,
            "position_type": actual_position_type,
            "buy_commission": buy_commission,
            "sell_commission": sell_commission
        }

        self.trade_history.append(trade)
        self.balance += net_sell_value

        logger.info(f"SELL executed | {symbol} | {actual_position_type} | pnl={round(pnl, 4)}")

        del self.positions[symbol]
        return trade

    # ======================================
    # SHOW PORTFOLIO
    # ======================================

    def show_portfolio(self):
        print()
        print("===== PORTFOLIO =====")
        print(f"USDT Balance: {round(self.balance, 2)}")
        print()

        if self.positions:
            print("Open Positions:")
            for symbol, position in self.positions.items():
                pos_type = position.get("position_type", "LONG")
                print(f"  {symbol}: {pos_type} | entry={position['entry_price']} | amount={position['amount']}")
        else:
            print("No open positions")

        print("=====================")
        print()

    # ======================================
    # SHOW TRADE HISTORY
    # ======================================

    def show_trade_history(self):
        print()
        print("===== TRADE HISTORY =====")
        if not self.trade_history:
            print("No trades yet")
        else:
            for trade in self.trade_history:
                pnl_sign = "+" if trade["pnl"] > 0 else ""
                print(f"  {trade['symbol']} | {trade['position_type']} | entry={trade['entry_price']} | exit={trade['exit_price']} | PnL={pnl_sign}{round(trade['pnl'], 4)}")
        print("=========================")
        print()

    # ======================================
    # CALCULATE PNL
    # ======================================

    def calculate_pnl(self, symbol, current_price):
        if symbol not in self.positions:
            return 0

        position = self.positions[symbol]
        entry_price = position["entry_price"]
        amount = position["amount"]
        position_type = position.get("position_type", "LONG")

        if position_type == "LONG":
            pnl = (current_price - entry_price) * amount
        else:  # SHORT
            pnl = (entry_price - current_price) * amount

        return pnl